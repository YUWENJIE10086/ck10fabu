# V6 complete Word audit; A=1094;B=465
depth=54238 chars, 8 diagrams
official=12294 chars,3 diagrams
10201004_01_获奖12篇及QC成果发布词深度学习.docx	49879 bytes
10201004_02_五万字项目研究卷_含QC与双模创新增订.docx	5294022 bytes
10201004_03_官方叙述一万字研究_成果报告与QC规范校订.docx	1493882 bytes
10201004_04_智烤管家V6_QC融合_8分钟AB正式演讲净稿.docx	29607 bytes
10201004_05_智烤管家V6_25页PPT双人演讲舞台稿.docx	30170 bytes
10201004_06_原稿及V1V5与QC融合修改对照.docx	37953 bytes
10201004_07_逐页演讲彩排与评委追问卡.docx	41192 bytes
10201004_08_QC发布词专项学习与V6成果化改写.docx	38587 bytes